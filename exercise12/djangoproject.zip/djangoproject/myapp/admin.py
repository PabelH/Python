from django.contrib import admin

from .models import Director, Movie

class MovieInLine(admin.StackedInline):
    model = Movie
    extra = 1

class DirectorAdmin(admin.ModelAdmin):
    fieldsets = [
        (None, {'fields': ('name', 'lastName', 'biography', 'photo')}),
        ('Dates', {
            'fields': ('birthday' , 'deathDate'),
            'classes' : 'collapse'
        }),
    ]
    inlines = [MovieInLine]


admin.site.register(Director)
admin.site.register(Movie)