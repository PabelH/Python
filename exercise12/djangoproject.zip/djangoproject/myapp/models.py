from django.db import models


class Director(models.Model):
    name = models.CharField(max_length=20)
    lastName = models.CharField(max_length=30)
    birthday = models.DateField()
    deathDate = models.DateField(null= True, blank = True)
    biography = models.TextField()
    photo = models.URLField()

    def __str__(self):
        return self.name + " " + self.lastName

class Movie(models.Model):
    director = models.ForeignKey('Director', on_delete=models.CASCADE)
    name = models.CharField(max_length=30)
    synopsis = models.TextField()
    length = models.PositiveIntegerField()
    image = models.URLField()
    year = models.PositiveIntegerField()

    def __str__(self):
        return self.name